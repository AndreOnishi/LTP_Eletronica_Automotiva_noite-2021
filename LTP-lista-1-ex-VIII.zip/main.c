#include <stdio.h>
#include <math.h>

int main(void) {
  float entrada_resistencia_R1,entrada_resistencia_R2,entrada_resistencia_R3,entrada_resistencia_R4;
  float saida_resistencia_equivalente;
  printf("entre com a resistencia_R1[Ohm]:");
  scanf("%f",&entrada_resistencia_R1);
  printf("entre com a resistencia_R2[Ohm]:");
  scanf("%f", &entrada_resistencia_R2);
  printf("entre com a resistencia_R3[Ohm]:");
  scanf("%f",&entrada_resistencia_R3);
  printf("entre com a resistencia_R4[Ohm]:");
  scanf("%f",&entrada_resistencia_R4);
  saida_resistencia_equivalente=1/(1/entrada_resistencia_R1+1/entrada_resistencia_R2+1/entrada_resistencia_R3+1/entrada_resistencia_R4);
  printf("resistencia_equivalente:%.3f [Ohm]\n",saida_resistencia_equivalente);
  return 0;
}