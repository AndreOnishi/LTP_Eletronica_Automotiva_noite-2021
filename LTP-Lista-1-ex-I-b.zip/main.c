#include "stdio.h"
#include <stdlib.h>
int main(void) {
  int e_nro_1, e_nro_2, e_nro_3;
  printf("Entre com o numero 1:");
  scanf("%i",&e_nro_1);
  printf("Entre com o numero 2:");
  scanf("%i" ,&e_nro_2);
  printf( "Entre com o numero 3:");
  scanf("%i",&e_nro_3);
  if(e_nro_1>e_nro_2){
    
    if(e_nro_2>e_nro_3){
      printf("%i e_nro_3\n",e_nro_3);
      printf("%i e_nro_2\n",e_nro_2);
      printf("%i e_nro_1\n",e_nro_1);

    }else
    {
      if(e_nro_1>e_nro_3){
        printf("%i e_nro_2\n",e_nro_2);
        printf("%i e_nro_3\n",e_nro_3);
        printf("%i e_nro_1\n",e_nro_1);
      }else
      {
        printf("%i e_nro_2\n",e_nro_2);
        printf("%i e_nro_1\n",e_nro_1);
        printf("%i e_nro_3\n",e_nro_3);
      }
      }
    }else if(e_nro_1>e_nro_3){
      printf("%i e_nro_3\n",e_nro_3);
      printf("%i e_nro_1\n",e_nro_1);
      printf("%i e_nro_2\n",e_nro_2);
      
    }else
    {
      if(e_nro_2>e_nro_3){
        printf("%i e_nro_1\n",e_nro_1);
        printf("%i e_nro_3\n",e_nro_3);
        printf("%i e_nro_2\n",e_nro_2);
      }else
      {
      printf("%i e_nro_1\n",e_nro_1);
      printf("%i e_nro_2\n",e_nro_2);
      printf("%i e_nro_3\n",e_nro_3);
      }
    
    }
    
        return 0;
}
