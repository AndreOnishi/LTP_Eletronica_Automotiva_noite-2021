   #include <stdio.h>
   
   int main(void)
   {
        int e_nro_1,e_nro_2,e_nro_3;
        printf("entre com o 1° numero:");
        scanf("%i", &e_nro_1);
        printf("entre com o 2° numero:");
        scanf("%i", &e_nro_2);
        printf("entre com o 3° numero:");
        scanf("%i", &e_nro_3);
               if (e_nro_1 > e_nro_2)                                          
           if (e_nro_2 > e_nro_3) 
           printf("%4i %4i %4i\n",e_nro_1,e_nro_2,e_nro_3);       
           else                                             
               if (e_nro_1 > e_nro_3) 
               printf("%4i %4i %4i\n", e_nro_1, e_nro_3, e_nro_2);   
               else printf("%4i %4i %4i\n", e_nro_3, e_nro_1, e_nro_2);         
     else                                                
           if (e_nro_2 > e_nro_3)                                       
               if (e_nro_1 > e_nro_3) 
               printf("%4i %4i %4i\n", e_nro_2, e_nro_1, e_nro_3);   
               else printf("%4i %4i %4i\n", e_nro_2, e_nro_3, e_nro_1);         
           else printf("%4i %4i %4i\n", e_nro_3 ,e_nro_2, e_nro_1);             
       return 0;
   }