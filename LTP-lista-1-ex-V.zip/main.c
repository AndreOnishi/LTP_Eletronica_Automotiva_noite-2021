#include<stdlib.h>     
#include<stdio.h>      
int main()
{
    float altura,peso_ideal;
    int sexo;
    printf("calculo de peso ideal.\n");
    printf("digite sua altura? ");
    scanf("%f",&altura);
    SEXO: printf("Qual seu sexo? 1=HOMEM 0=MULHER: ");
    scanf("%d",&sexo);
    switch(sexo)      
    {
    case 1:          
         {peso_ideal=(72.7*altura)-58;
         printf("peso ideal  %.2f quilos\n\n",peso_ideal);
         }
         break;
    case 0:    
         {peso_ideal=(62.1*altura)-44.7;
         printf("peso ideal  %.2f quilos\n\n",peso_ideal);
         }
         break;
    default: {printf("OPCAO INVALIDA\n");             }
    }
return 0;    
}
