#include "stdio.h"
int main(void) {
  int var_a,var_b,var_tmp;
  printf("entre com o valor da var_a:");
  scanf("%i",&var_a);
  printf("entre com o valor da var_b:");
  scanf("%i",&var_b);
  var_tmp=var_a;
  var_a=var_b;
  var_b=var_tmp;
  
   printf("var_a:%i\n",var_a);
   printf("var_b:%i\n",var_b);
  return 0;
}