#include <stdio.h>

int main(void) {
  float entrada_resistencia_R1,entrada_resistencia_R2,entrada_resistencia_R3,entrada_resistencia_R4;
  float saida_resistencia_equivalente;
  printf("numero decimal nao use virgula e sim ponto.\n");

  printf("entre com a resistencia_R1[Ohm]:");
  scanf("%f",&entrada_resistencia_R1);
  printf("entre com a resistencia_R2 [Ohm]");
  scanf("%f", &entrada_resistencia_R2);
  printf("entre com a resistencia_R3[Ohm]:");
  scanf("%f",&entrada_resistencia_R3);
  printf("entre com a resistencia_R4[Ohm]:");
  scanf("%f",&entrada_resistencia_R4);
  saida_resistencia_equivalente=entrada_resistencia_R1+entrada_resistencia_R2+entrada_resistencia_R3+entrada_resistencia_R4;
  printf("resistencia_equivalente: %.2f [Ohm]\n",saida_resistencia_equivalente);
  return 0;
}